from django.test import TestCase

SetEnvIf X-Url-Scheme https HTTPS=1 

# Create your tests here.
